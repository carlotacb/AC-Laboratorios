#include "CacheSim.h"

/* Posa aqui les teves estructures de dades globals
 * per mantenir la informacio necesaria de la cache
 * */

struct {
    int tag;
    int validesa;
} directa


directa cache[128]; // tenim 32 blocs

/* La rutina init_cache es cridada pel programa principal per
 * inicialitzar la cache.
 * La cache es inicialitzada al comen�ar cada un dels tests.
 * */
void init_cache ()
{
    totaltime=0.0;
    /* Escriu aqui el teu codi */

    int i;

    for (i = 0; i < 1024; ++i) {
        cache[i].tag = -1;
        cache[i].validesa = 0;
    }

}

/* La rutina reference es cridada per cada referencia a simular */
void reference (unsigned int address)
{
	unsigned int byte;              // byte que utilitza.
	unsigned int bloque_m;          // Bloc de memoria accedit
	unsigned int linea_mc;          // linea de la memoria cache utilitzada
	unsigned int tag;               // etiqueta que posem a la linea de mem cache
	unsigned int miss;	            // boolea que ens indica si es miss
	unsigned int replacement;       // boolea que indica si es reempla�a una linia valida
	unsigned int tag_out;	        // TAG de la linia reempla�ada
	float t1,t2;		            // Variables per mesurar el temps (NO modificar)

	t1=GetTime();

	/* Escriu aqui el teu codi */

	unsigned int adr = address;

	miss = 0; // false
	replacement = 0; // false
	tag_out = -1; // no hi ha linea reempla�ada pel moment

	byte = adr & 31; // 5 ultims bits

	bloque_m = adr >> 5;  // linea_mc + tag --> 27 bits inicials

	linea_mc = adr & 4064;  // 7 bits del mitj
	linea_mc = linea_mc >> 5;

	tag = adr >> 12; // 20 bits inicials


	if (cache[linea_mc].validesa != 0 && cache[linea_mc].tag != tag) {
        miss = 1; // true
        replacement = 1; // true
        tag_out = cache[linea_mc].tag;
        cache[linea_mc].tag = tag;
	}

	else if (cache[linea_mc].validesa == 0) {
        miss = 1; // true
        replacement = 0; // false
        cache[linea_mc].tag = tag;
	}

	else {
        miss = 0; // false
        replacement = 0; // false
	}

	/* La funcio test_and_print escriu el resultat de la teva simulacio
	 * per pantalla (si s'escau) i comproba si hi ha algun error
	 * per la referencia actual. Tamb� mesurem el temps d'execuci�
	 * */

	t2=GetTime();
	totaltime+=t2-t1;
	test_and_print (address, byte, bloque_m, linea_mc, tag, miss, replacement, tag_out);
}

/* La rutina final es cridada al final de la simulacio */
void final ()
{
 	/* Escriu aqui el teu codi */


}
