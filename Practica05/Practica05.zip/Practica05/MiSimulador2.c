#include "CacheSim.h"

/* Posa aqui les teves estructures de dades globals
 * per mantenir la informacio necesaria de la cache
 * */


struct {
    int tvia0;
    int tvia1;
    int validesa0;
    int validesa1;
    int LRU;
} conjunt


conjunt cache[128]; // tenim 32 blocs

/* La rutina init_cache es cridada pel programa principal per
 * inicialitzar la cache.
 * La cache es inicialitzada al comen�ar cada un dels tests.
 * */
void init_cache ()
{
    totaltime = 0.0;
	/* Escriu aqui el teu codi */

	int i;

    for (i = 0; i < 1024; ++i) {
        cache[i].tvia0 = -1;
        cache[i].tvia1 = -1;
        cache[i].validesa1 = 0;
        cache[i].validesa2 = 0;
        cache[i].LRU = -1;
    }
}

/* La rutina reference es cridada per cada referencia a simular */
void reference (unsigned int address)
{
	unsigned int byte;
	unsigned int bloque_m;
	unsigned int conj_mc;
	unsigned int via_mc;
	unsigned int tag;
	unsigned int miss;	   // boolea que ens indica si es miss
	unsigned int replacement;  // boolea que indica si es reempla�a una linia valida
	unsigned int tag_out;	   // TAG de la linia reempla�ada
	float t1,t2;		// Variables per mesurar el temps (NO modificar)

	t1=GetTime();
	/* Escriu aqui el teu codi */

	unsigned int adr = address;

	miss = 0;
	replacement = 0;
	tag_out = -1;
    via_mc = 0;

    byte = adr & 31;        // 5 bits ultims
    bloque_m = adr >> 5;    // 27 bits inicials
    conj_mc = adr & 2016;     // 6 bits del mitj
    conj_mc = conj_mc >> 5;
    tag = adr >> 11;         // 21 bits inicials

    if (cache[conj_mc].validesa0 == 0) { // la via0 esta buida
        miss = 1; // true
        cache[conj_mc].tvia0 = tag;
        replacement = 0; // false
        cache[conj_mc].LRU = 1;
        via_mc = 0;
    }

    else {

        if (cache[conj_mc].tvia0 != tag) {

            if (cache[conj_mc].validesa1 == 0) { // la via1 esta buida i tag != tvia0

                miss = 1; // true
                replacement = 0; // false
                cache[conj_mc].tvia1 = tag;
                cache[conj_mc].LRU = 0;
                via_mc = 1;

            }
            else {
                if (cache[conj_mc].tvia1 != tag) { // tag != tvia0 i tvia1 i les dos vies estan ocupades

                    if (cache[conj_mc].LRU == 0) { // utilitzem la via0
                        miss = 1; // true
                        replacement = 1; // true
                        tag_out = cache[conj_mc].tvia0;
                        cache[conj_mc].tvia0 = tag;
                        cache[conj_mc].LRU = 1;
                        via_mc = 0;
                    }
                    else { // utilitzem la via1
                        miss = 1; // true
                        replacement = 1; // true
                        tag_out = cache[conj_mc].tvia1;
                        cache[conj_mc].tvia1 = tag;
                        cache[conj_mc].LRU = 0;
                        via_mc = 1;
                    }

                }
                else { // HIT
                    miss = 0; // false
                    replacement = 0; // false
                    cache[conj_mc].LRU = 0;
                    via_mc = 1;

                }

            }

        }
        else { // FA HIT
            miss = 0; // false
            replacement = 0;
            cache[conj_mc].LRU = 1;
            via_mc = 0;
        }

    }

}

	/* La funcio test_and_print escriu el resultat de la teva simulacio
	 * per pantalla (si s'escau) i comproba si hi ha algun error
	 * per la referencia actual. Tamb� mesurem el temps d'execuci�
	 * */
	t2=GetTime();
	totaltime+=t2-t1;

	test_and_print2 (address, byte, bloque_m, conj_mc, via_mc, tag,
			miss, replacement, tag_out);
}

/* La rutina final es cridada al final de la simulacio */
void final ()
{
 	/* Escriu aqui el teu codi */


}
